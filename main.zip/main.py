from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from threading import Thread
import os, time, random, requests, signal
from html import unescape
from scratchattach import Session, CloudRequests, TwCloudRequests, CloudEvents, WsCloudEvents, get_cloud_logs, TwCloudConnection

class UnknownIdError(Exception):
  pass

password = os.getenv("MONGO_DB_KEY")
session_id = os.getenv("SESSION")

uri = f"mongodb+srv://main:{password}@smilingglass.x6opr0j.mongodb.net/?retryWrites=true&w=majority"

# Create a new client and connect to the server
mongoclient = MongoClient(uri, server_api=ServerApi('1'))

# Send a ping to confirm a successful connection
mongoclient.admin.command('ping')
print("Pinged your deployment. You successfully connected to MongoDB!")

db = mongoclient["maindatabase"]
levels = db["levels"]
users = db["users"]
tabs = db["tabs"]

session = Session(session_id, username="SmilingGlass")
project = session.connect_project(878185237) # 873151153 (Yangoose_test's project) and 877058947 
conn = session.connect_cloud(878185237)
twconn = TwCloudConnection(project_id=878185237, username="player1000")

client = CloudRequests(conn, used_cloud_vars=["1", "2", "3"])
twclient = TwCloudRequests(twconn, used_cloud_vars=["1", "2", "3"])

def find_level(level_id=None, *, level_name=None):
  if level_id is not None:
    try:
      level = levels.find_one({"level_id": level_id})
      assert level is not None
      return level
    except Exception as e:
      raise UnknownIdError("The level corresponding to your level id was not found.")
  if level_name is None:
    raise ValueError("You provided neither a level id nor a level name to find your level.")
  try:
    search_results = levels.find({"name": level_name})
    assert len(search_results)
    return levels[0]
  except:
    raise ValueError("There was no level found with that name.")
  
def update_level(level_id, update):
  levels.update_one({"level_id": level_id}, update)

def insert_level(level_id, level=None):
  level = {} if level is None else level
  level["views"] = 0
  level["likes"] = []
  level["level_id"] = level_id
  levels.insert_one(level)

def rate_level(level): # Insert level into the popular page and the trending page
  popularity = level.get("popularity", 0) # For trending page
  rating = level.get("views") + 8 * len(level.get("likes", ())) # For popular page
  # Insert level into the popular page
  popular = tabs.find_one({"type": "popular"})["content"]
  remove = None
  insert_idx = -1
  for idx, (other_level, other_rating) in enumerate(popular.copy()):
    if level["level_id"] == other_level["level_id"]:
      remove = idx
    elif rating > other_rating:
      if insert_idx >= 0:
        continue
      insert_idx = idx
  if insert_idx == -1:
    popular.append([level, rating])
  else:
    popular.insert(insert_idx, [level, rating])
    if remove is not None and insert_idx < remove:
      remove += 1
  if remove is not None:
    popular.pop(remove)
  popular = popular[:20]
  tabs.update_one({"type": "popular"}, {"$set": {"content": popular}})
  # Insert level into the trending page
  trending = tabs.find_one({"type": "trending"})["content"]
  remove = None
  insert_idx = -1
  for idx, (other_level, other_popularity) in enumerate(trending.copy()):
    if level["level_id"] == other_level["level_id"]:
      remove = idx
    elif popularity > other_popularity:
      if insert_idx >= 0:
        continue
      insert_idx = idx
  if insert_idx == -1:
    trending.append([level, popularity])
  else:
    trending.insert(insert_idx, [level, popularity])
    if remove is not None and insert_idx < remove:
      remove += 1
  if remove is not None:
    trending.pop(remove)
  trending = trending[:20]
  tabs.update_one({"type": "trending"}, {"$set": {"content": trending}})

def find_comment(username):
  return unescape([comment["content"] for comment in project.comments() if comment["author"]["username"] == username][0])

def find_last_commenter(code):
  return [comment["author"]["username"] for comment in project.comments() if comment["content"].startswith(f"{code}: ")][0]

def authenticate_user(username, level_id):
  level = find_level(level_id)
  if not username in level["can_edit"]:
    raise Exception

@client.request(name="save_level")
def save_level(level_id, update_name, *level_data):
  level_data = "&".join(level_data)
  update_name = int(update_name)
  try:
    find_level(level_id)
    try:
      authenticate_user(client.get_requester(), level_id)
    except Exception:
      return "NO PERMISSION"
    set_data = {"data": level_data}
    if update_name:
      try:
        set_data["name"] = find_comment(client.get_requester())
      except IndexError:
        return "NO COMMENT"
    update_level(level_id, {"$set": set_data})
    return "UPDATED"
  except UnknownIdError:
    level_name = ""
    try:
      level_name = find_comment(client.get_requester())
    except Exception:
      return "NO COMMENT"
    insert_level(level_id, {"name": level_name, "data": level_data, "owner": client.get_requester(), "can_edit": [client.get_requester()]})
    content = tabs.find_one({"type": "new"})["content"]
    content.append(level_id)
    content = content[-20:]
    rate_level(find_level(level_id))
    tabs.update_one({"type": "new"}, {"$set": {"content": content}})
    return "CREATED"

@client.request(name="load_level")
def load_level(level_id):
  level = find_level(level_id)
  popularity = level.get("popularity", 0)
  popularity_timestamp = level.get("popularity_timestamp", 0)
  popularity *= 0.99 ** ((time.time() - popularity_timestamp) / 3600)
  popularity += 0.01
  level["popularity"] = popularity
  rate_level(level)
  update_level(level_id, {"$inc": {"views": 1}, "$set": {"popularity": popularity, "popularity_timestamp": time.time()}})
  return find_level(level_id)["data"]

@client.request(name="like_level")
def like_level(level_id):
  level = find_level(level_id)
  likes = level["likes"]
  if client.get_requester() in likes:
    return "FAILURE"
  popularity = level.get("popularity", 0)
  popularity_timestamp = level.get("popularity_timestamp", 0)
  popularity *= 0.99 ** ((time.time() - popularity_timestamp) / 3600)
  popularity += 1
  likes.append(client.get_requester())
  level["likes"] = likes
  level["popularity"] = popularity
  rate_level(level)
  update_level(level_id, {"$set": {"likes": likes, "popularity": popularity, "popularity_timestamp": time.time()}})
  return "SUCCESS"

@client.request(name="unlike_level")
def unlike_level(level_id):
  level = find_level(level_id)
  likes = level["likes"]
  if not client.get_requester() in likes:
    return "FAILURE"
  popularity = level.get("popularity", 0)
  popularity_timestamp = level.get("popularity_timestamp", 0)
  popularity *= 0.99 ** ((time.time() - popularity_timestamp) / 3600)
  popularity -= 1
  likes.remove(client.get_requester())
  level["likes"] = likes
  level["popularity"] = popularity
  rate_level(level)
  update_level(level_id, {"$set": {"likes": likes, "popularity": popularity, "popularity_timestamp": time.time()}})
  return "SUCCESS"

def concatenate_levels(levels):
  level_data = []
  for level in levels:
    level_data.extend([
      level["name"],
      level["owner"],
      level["views"],
      len(level["likes"]),
      level["level_id"],
      "" # Placeholder
    ])
  return level_data

@client.request(name="load_tab")
def load_tab(tab):
  match tab:
    case "new":
      return concatenate_levels(find_level(level_id) for level_id in reversed(tabs.find_one({"type": "new"})["content"]))
    case "popular":
      return concatenate_levels(level for level, rating in tabs.find_one({"type": "popular"})["content"])
    case "trending":
      return concatenate_levels(level for level, popularity in tabs.find_one({"type": "trending"})["content"])

@client.request(name="load_coins")
def load_coins():
  user = users.find_one({"username": client.get_requester()})
  coins = 0 if user is None else user.get("coins", 0)
  return coins

@client.request(name="set_coins")
def set_coins(coins):
  user = users.find_one({"username": client.get_requester()})
  if user is None:
    users.insert_one({"username": client.get_requester(), "coins": coins})
    return "DONE"
  users.update_one({"username": client.get_requester()}, {"$set": {"coins": coins}})
  return "DONE"

@twclient.request(name="load_all")
def load_all():
  user = users.find_one({"username": client.get_requester()})
  coins = 0 if user is None else user.get("coins", 0)
  shop = [] if user is None else user.get("shop", [])
  return [coins, *shop]

@twclient.request(name="set_all")
def set_all(coins, *shop):
  user = users.find_one({"username": client.get_requester()})
  if user is None:
    users.insert_one({"username": client.get_requester(), "coins": coins, "shop": shop})
    return "DONE"
  users.update_one({"username": client.get_requester()}, {"$set": {"coins": coins, "shop": shop}})
  return "DONE"

@twclient.request(name="save_level")
def save_level(level_id, update_name, *level_data):
  code = level_id
  username = find_last_commenter(code)
  level_data = "&".join(level_data)
  update_name = int(update_name)
  try:
    find_level(level_id)
    try:
      authenticate_user(username, level_id)
    except Exception:
      return "NO PERMISSION"
    set_data = {"data": level_data}
    if update_name:
      try:
        set_data["name"] = find_comment(username).removeprefix(f"{code}: ")
      except IndexError:
        return "NO COMMENT"
    update_level(level_id, {"$set": set_data})
    return "UPDATED"
  except UnknownIdError:
    level_name = ""
    try:
      level_name = find_comment(username).removeprefix(f"{code}: ")
    except Exception:
      return "NO COMMENT"
    insert_level(level_id, {"name": level_name, "data": level_data, "owner": client.get_requester(), "can_edit": [client.get_requester()]})
    content = tabs.find_one({"type": "new"})["content"]
    content.append(level_id)
    content = content[-20:]
    rate_level(find_level(level_id))
    tabs.update_one({"type": "new"}, {"$set": {"content": content}})
    return "CREATED"

@twclient.request(name="load_level")
def load_level(level_id):
  level = find_level(level_id)
  popularity = level.get("popularity", 0)
  popularity_timestamp = level.get("popularity_timestamp", 0)
  popularity *= 0.99 ** ((time.time() - popularity_timestamp) / 3600)
  popularity += 0.01
  level["popularity"] = popularity
  rate_level(level)
  update_level(level_id, {"$inc": {"views": 1}, "$set": {"popularity": popularity, "popularity_timestamp": time.time()}})
  return find_level(level_id)["data"]

@twclient.request(name="like_level")
def like_level(level_id):
  level = find_level(level_id)
  likes = level["likes"]
  popularity = level.get("popularity", 0)
  popularity_timestamp = level.get("popularity_timestamp", 0)
  popularity *= 0.99 ** ((time.time() - popularity_timestamp) / 3600)
  popularity += 1
  likes.append("tw")
  level["likes"] = likes
  level["popularity"] = popularity
  rate_level(level)
  update_level(level_id, {"$set": {"likes": likes, "popularity": popularity, "popularity_timestamp": time.time()}})
  return "SUCCESS"

@twclient.request(name="unlike_level")
def unlike_level(level_id):
  level = find_level(level_id)
  likes = level["likes"]
  if not "tw" in likes:
    return "FAILURE"
  popularity = level.get("popularity", 0)
  popularity_timestamp = level.get("popularity_timestamp", 0)
  popularity *= 0.99 ** ((time.time() - popularity_timestamp) / 3600)
  popularity -= 1
  likes.remove("tw")
  level["likes"] = likes
  level["popularity"] = popularity
  rate_level(level)
  update_level(level_id, {"$set": {"likes": likes, "popularity": popularity, "popularity_timestamp": time.time()}})
  return "SUCCESS"

@twclient.request(name="load_tab")
def load_tab(tab):
  match tab:
    case "new":
      return concatenate_levels(find_level(level_id) for level_id in reversed(tabs.find_one({"type": "new"})["content"]))
    case "popular":
      return concatenate_levels(level for level, rating in tabs.find_one({"type": "popular"})["content"])
    case "trending":
      return concatenate_levels(level for level, popularity in tabs.find_one({"type": "trending"})["content"])

@twclient.request(name="load_coins")
def load_coins():
  return 0

@twclient.request(name="set_coins")
def set_coins(coins):
  return "DONE"


@twclient.request(name="load_all")
def load_all():
  return 0

@twclient.request(name="set_all")
def set_all(*data):
  return "DONE"

client.run(thread=True)
twclient.run(thread=True) # Requests needed (modified)
time.sleep(1800) # Wait 30 minutes
print("Done")
pgid = os.getpgid(os.getpid())
os.killpg(pgid, signal.SIGINT) # End the process
